#!/bin/sh
# ===NAME====================================================================================================
#    install.sh CHECK|INSTALL|UNINSTALL
# ===DESCRIPTION=============================================================================================
#    Install daemon grid-monitor and cgis
# ===LICENSE=================================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ===========================================================================================================
scriptName=$0;invocationString=$*;numParam="$#";inputAction=$1
currentPath="."
. $currentPath/grid-monitor-install.conf

function sys_init {
	currentDateFull=$(date '+%Y%m%d-%H%M%S');currentYear=$(date '+%Y');currentMonth=$(date '+%m');currentDay=$(date '+%d')
	currentDate=$currentYear$currentMonth$currentDay;currentMonthDay=$currentMonth$currentDay;currentYearMonth=$currentYear$currentMonth;previousYear=""
	architecture=$(uname -a | cut -f1 -d" ");currentHostName=$(hostname);currentUser=$(id -un)
	fileLog="$currentPath/${scriptName}-${currentDate}.log"	
	[ "$scriptName" ] || scriptName=$0
	BRED="\033[37m\033[1m\033[41m";BBLUE="\033[37m\033[1m\033[44m";BGREEN="\033[37m\033[1m\033[42m";RESET="\033[0m";FontBold="\033[1m"
        BYELLOW="\033[37m\033[1m\033[43m";BPURPLE="\033[37m\033[1m\033[45m";BCIAN="\033[37m\033[1m\033[46m";BBLACK="\033[37m\033[1m\033[40m";BGRAY="\033[1m\033[47m";
	MOK="${BGREEN}  OK   ${RESET}";MERROR="${BRED} ERROR ${RESET}";MSTART="${BBLUE} START ${RESET}";MEND="${BBLUE}  END  ${RESET}";MWARNG="${BYELLOW} WARNG ${RESET}";MINFO="${BBLACK} INFO  ${RESET}";MDEBUG="${BPURPLE} DEBUG ${RESET}";MEXIT="${BRED} EXIT ${RESET}"
	pathEtc=$pathBase/etc;pathLog=$pathBase/log;pathTmp=$pathBase/tmp;pathDat=$pathBase/dat
	[ "$fileLog" ] || fileLog="${pathLog}/${scriptName}-${currentDate}.log"
}
function sys_writeToLog {
        fileLog=$1;MESSAGELOG=$2
	if [ "$fileLog" = "" ];then
		echo "${MWARNG}: No se ha definido la variable fileLog."
		[ "$architecture" = "HP-UX" ] && echo $(date '+%b %d %H:%M:%S')" $MESSAGELOG" || echo -e $(date '+%b %d %H:%M:%S')" $MESSAGELOG"
	else
		[ ! -e $fileLog ] && touch $fileLog && chmod 666 $fileLog
        	[ "$architecture" = "HP-UX" ] && echo $(date '+%b %d %H:%M:%S')" $MESSAGELOG" | tee -a $fileLog || echo -e $(date '+%b %d %H:%M:%S')" $MESSAGELOG" | tee -a $fileLog		
	fi
}
function sys_checkExistsAndCreate {
        targetCreate=$1
        [ -f $targetCreate ] && sys_writeToLog $fileLog "${MERROR}: $targetCreate es un fichero." && exit 1
        [ ! -e $targetCreate ] && sys_writeToLog $fileLog "${MINFO}: No Existe $targetCreate se procede a crearlo." && mkdir -p $targetCreate
}
function sys_checkExists {
        targetCheck=$1;[ ! -e $targetCheck ] && sys_writeToLog $fileLog "${MERROR}: No Existe: $targetCheck ${MEXIT}" && exit 1
}
function sys_checkUser {
	targetUser=$1
	[ "$currentUser" != "$targetUser" ] && sys_writeToLog $fileLog "${MERROR}: este script se debe de ejecutar con usuario $targetUser ${MEXIT}" && exit 1
}
function sys_checkStatusExecution {
	##Ejemplo: sys_checkStatusExecution $? "Ejecución de Totales.sh" $fileLog EXIT
        exitTermination=$1;Message=$2;fileLog=$3;exitShell=$4
        if [ $exitTermination -ne 0 ];then
                 sys_writeToLog $fileLog "${MERROR}: ${Message}"
                 [ "$exitShell" = "EXIT" ] && exit $exitTermination
        else
                 sys_writeToLog $fileLog "${MOK}: ${Message}"
        fi
}
function sys_checkSSH {
        userOrigin=$1;userTarget=$2;serverTarget=$3
        su ${userOrigin} -c "ssh -o \"BatchMode yes\" -n ${userTarget}@${serverTarget} uptime" > /dev/null 2>&1
        if [ $? -ne 0 ];then
	    sys_writeToLog $fileLog "${MINFO}: ${BRED} NO-CONNECTION ${RESET}: SSH Connection ${BRED}$currentHostName($userOrigin) -----> $serverTarget($userTarget)${RESET} Check .ssh/authorized_keys ${MEXIT}"
	    exit 1
	else
	    sys_writeToLog $fileLog "${MINFO}: ${BGREEN} OK-CONNECTION ${RESET}: SSH Connection ${FontBold}$currentHostName($userOrigin) -----> $serverTarget($userTarget)${RESET}"
	fi
}


### checks_ ###
function start_environment {
	typeAction=$1
	messageHtml="<table align=center width=80%><tr><td width=15% align=center><b>START</b></td><td width=75% align=left><b>${typeAction} ${currentHostName}</b></td></tr>"
	HOK="<td align=center><font color=\"#098c15\"><b>OK</b></font></td>";HERROR="<td align=center><font color=\"#FF0000\"><b>ERROR</b></font></td>"	
	sys_writeToLog $fileLog "${typeAction}: $MSTART"
}
function end_environment {
	typeAction=$1
	messageHtml="${messageHtml}<tr><td align=center><b>END</b></td><td align=left><b>${typeAction} end.</b></td></tr></table>"
	sys_writeToLog $fileLog "${typeAction}: $MEND"
}
function check_apache {
	sys_checkExists $pathcgiBinApache
	sys_checkExists $pathDocsApache
}
function check_sungrid {
	sys_checkExists $pathGRID
}

### setups_ ###

function setup_copy_resources {
	[ -e $pathcgiBinApache/grid-monitor ] && rm -Rf $pathcgiBinApache/grid-monitor
	[ -e $pathDocsApache/grid-monitor ] && rm -Rf $pathDocsApache/grid-monitor
	[ -e $pathBaseInstallation/grid-monitor ] && rm -Rf $pathBaseInstallation/grid-monitor
	mkdir -p $pathcgiBinApache/grid-monitor
	sys_checkStatusExecution $? "created: $pathcgiBinApache/grid-monitor" $fileLog EXIT
	mkdir -p $pathDocsApache/grid-monitor
	sys_checkStatusExecution $? "created: $pathDocsApache/grid-monitor" $fileLog EXIT
	cp -Rp $currentPath/grid-monitor $pathBaseInstallation
	sys_checkStatusExecution $? "copy $currentPath/grid-monitor to $pathBaseInstallation" $fileLog EXIT
	cp -Rp $currentPath/grid-monitor-www/cgi-bin/grid-monitor $pathcgiBinApache
	sys_checkStatusExecution $? "copy $currentPath/grid-monitor-www/cgi-bin/grid-monitor to $pathcgiBinApache" $fileLog EXIT
	cp -Rp $currentPath/grid-monitor-www/docs/grid-monitor $pathDocsApache
	sys_checkStatusExecution $? "copy $currentPath/grid-monitor-www/docs/grid-monitor to $pathDocsApache" $fileLog EXIT
	chown -R $userSSHMonitor:$groupSSHMonitor $pathBaseInstallation/grid-monitor
	chmod 755 $pathBaseInstallation/grid-monitor/bin/*
	chmod 755 $pathcgiBinApache/grid-monitor/*
	chmod 755 $pathcgiBinApache/grid-monitor/scripts/*
}
function setup_configuration {
	sys_checkExists $pathBase/etc
	configFile="$pathBase/etc/grid-configuration.yaml"
	echo "configuracion:" > $configFile
	echo "        gridName: $gridName" >> $configFile
	echo "        gridNameShort: $gridNameShort" >> $configFile
	echo "        gridNameText: $gridNameText" >> $configFile
	echo "        gridNameHostSub: $gridNameHostSub" >> $configFile
	echo "        sgeRoot: $sgeRoot" >> $configFile
	echo "        sgeSpool: $sgeSpool" >> $configFile
	echo "        sgeCell: $sgeCell" >> $configFile
	echo "        sgeClusterName: $sgeClusterName" >> $configFile
	echo "        sgeQmasterPort: $sgeQmasterPort" >> $configFile
	echo "        sgeExecdPort: $sgeExecdPort" >> $configFile
	echo "        pathGRID: $pathGRID" >> $configFile
	echo "        pathBase: $pathBase" >> $configFile
	echo "        pathDataFiles: $pathDataFiles" >> $configFile
	echo "        pathWrk: $pathWrk" >> $configFile
	echo "        pathLog: $pathLog" >> $configFile
	echo "        pathLogProcess: $pathLogProcess" >> $configFile
	echo "        pathEtc: $pathEtc" >> $configFile
	echo "        pathJavaScripts: $pathJavaScripts" >> $configFile
	echo "        pathStyleSheet: $pathStyleSheet" >> $configFile
	echo "        pathImages: $pathImages" >> $configFile
	echo "        nameFileLista: gridTasks" >> $configFile
	echo "        nameFileEstado: gridStates" >> $configFile
	echo "        nameFileMonitorHosts: gridMonitorHosts.dat" >> $configFile
	echo "        nameFileMonitorQueues: gridMonitorQueues.dat" >> $configFile
	echo "        nameFileDaemonsLista: daemons-list.dat" >> $configFile
	echo "        nameFileDaemonsEstado: gridDaemonsStates" >> $configFile
	echo "        url: $url" >> $configFile
	echo "        urlBase: $urlBase" >> $configFile
	echo "        urlAjaxScripts: $urlAjaxScripts" >> $configFile	
	echo "        sleepTimeTasks: $sleepTimeTasks" >> $configFile
	echo "        sleepTimeHosts: $sleepTimeHosts" >> $configFile
	echo "        userSSHMonitor: $userSSHMonitor" >> $configFile	
}
function delete_resources {
	rm -Rf $pathBaseInstallation/grid-monitor
	sys_checkStatusExecution $? "remove $pathBaseInstallation/grid-monitor" $fileLog EXIT
	rm -Rf $pathcgiBinApache/grid-monitor
	sys_checkStatusExecution $? "remove $pathcgiBinApache/grid-monitor" $fileLog EXIT
	rm -Rf $pathDocsApache/grid-monitor
	sys_checkStatusExecution $? "remove $pathDocsApache/grid-monitor" $fileLog EXIT
}

### mains_ ###
function main_check {
	start_environment "CHECK"
	sys_checkExistsAndCreate $pathBase
	check_apache
	check_sungrid 
        for targetExecutionHost in $gridExecutionHosts
        do
		sys_checkSSH "$userSSHMonitor" "$userSSHMonitor" "$targetExecutionHost"
	done 
	end_environment "CHECK"
}

function main_install {
	start_environment "INSTALL"
	setup_copy_resources
	setup_configuration
	end_environment "INSTALL"
}

function main_uninstall {
	start_environment "UNINSTALL"
	delete_resources
	end_environment "UNINSTALL"
}

function main {
	sys_checkUser root
	case $inputAction in
	CHECK)
		main_check
	;;
	INSTALL)
		main_check
		main_install
	;;
	UNINSTALL)
		main_uninstall
	;;
	*)
		sys_writeToLog $fileLog "${MERROR} Error en parámetros, se esparaba: CHECK|INSTALL|UNINSTALL"
	;;
	esac
}

sys_init
main





