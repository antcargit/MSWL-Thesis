#!/bin/bash
#
# Start script for grid-monitor
#
# chkconfig: - 87 13
# description: Monitor del Grid
# processname: grid-monitor
# pidfile: /var/run/grid-monitor.pid
#
# Source function library.
. /etc/rc.d/init.d/functions
RETVAL=0
prog="grid-monitor"
pidfile=/var/run/grid-monitor.pid
GRIDUSER=root
# start, debug, stop, and status functions
start() {
        # Start daemons.
        echo -n $"Starting Grid Monitor"
        touch $pidfile
        ## chown $WL_USER:$WL_USER $pidfile
        ##daemon --user $WL_USER /bea/init.d/$prog
        currentDate=$(date '+%Y%m%d')
        daemon --user $GRIDUSER "nohup /opt/grid-monitor/bin/grid-monitor.rb > /opt/grid-monitor/log/grid-service-${currentDate}.log 2>&1 &"
        RETVAL=$?
        echo
        [ $RETVAL -eq 0 ] && touch /var/lock/subsys/grid-monitor
        return $RETVAL
}
stop() {
        # Stop daemons.
        echo -n $"Shutting down $prog: "
        PROCESO=`ps -ef | grep grid-monitor | grep -v grep | grep -v vi`
        echo "Proceso $PROCESO"
        PID=`ps -ef | grep grid-monitor | grep -v grep | grep -v vi | awk '{ print $2 }'`
        kill -9 $PID
        RETVAL=$?
        echo
        [ $RETVAL -eq 0 ] && rm -f /var/lock/subsys/grid-monitor
        return $RETVAL
}
status() {
        PID=`ps -ef | grep grid-monitor | grep -v grep | grep -v vi | awk '{ print $2 }'`
        echo
        if [ -z $PID ]
        then
            echo "gridmonitor is stopped !!!"
            return 3
        fi
        echo "gridmonitor is started."
        echo
        return 0
}
case "$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  restart)
        stop
        start
        ;;
  status)
        status
        RETVAL=$?
        ;;
  *)
        echo "Usage: $0 {start|stop|restart|status}"
        exit 1
esac
exit $RETVAL

