#!/usr/bin/ruby
# ===NAME==========================================================================================
#    ajaxSungridQueueList.rb
# ===DESCRIPTION===================================================================================
#    Este cgi devuelve una lista con las colas disponibles
# ===LICENSE=======================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ==================================================================================================
require 'yaml'

fileConfig="/opt/grid-monitor/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)

PathSunGridEngine=config["configuracion"]["pathGRID"]
ENV['SGE_ROOT']=config["configuracion"]["sgeRoot"]
ENV['SGE_CELL']=config["configuracion"]["sgeCell"]
ENV['SGE_CLUSTER_NAME']=config["configuracion"]["sgeClusterName"]
ENV['SGE_QMASTER_PORT']=config["configuracion"]["sgeQmasterPort"].to_s
ENV['SGE_EXECD_PORT']=config["configuracion"]["sgeExecdPort"].to_s

def getExecutionHostQueueList()
        #[root@deltaweb 2010]# qhost  -q
        #HOSTNAME                ARCH         NCPU  LOAD  MEMTOT  MEMUSE  SWAPTO  SWAPUS
        #-------------------------------------------------------------------------------
        #global                  -               -     -       -       -       -       -
        #delta0                  lx24-amd64      1  0.00    1.0G  145.4M    2.0G     0.0
        #   i                    BIP   0/0/5         
        #   k                    BIP   0/0/5         
        #delta1                  lx24-amd64      1  0.00    1.0G  112.1M    2.0G     0.0
        #   i                    BIP   0/0/5         
        #   n                    BIP   0/0/1        
        #  qhost sin parametros da esto
        #HOSTNAME                ARCH         NCPU  LOAD  MEMTOT  MEMUSE  SWAPTO  SWAPUS
        #-------------------------------------------------------------------------------
        #global                  -               -     -       -       -       -       -
        #delta0                  lx24-amd64      1     -    1.0G       -    2.0G       -
        #delta1                  lx24-amd64      1  0.00    1.0G   82.6M    2.0G     0.0
   exeHostQueueList=Hash.new("")
   outPut=`#{PathSunGridEngine}/bin/lx24-amd64/qhost -q`
   outPut.each do | linea |
       if /^(\S+)\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+$/.match(linea) then
           if ($1 != "global" && $1 != "HOSTNAME")then 
                currentHost=$1
           end
       elsif /^\s+(\S+)\s+\S+\s+\d+\/\d+\/(\d+)\s*/.match(linea) then
           if exeHostQueueList[currentHost]=="" then
                  exeHostQueueList[currentHost]=$1+";"+$2   ######
           else
                   exeHostQueueList[currentHost]="#{exeHostQueueList[currentHost]},#{$1};#{$2}"
           end
       end
   end
   return exeHostQueueList
end


def returnHTML(message)
puts <<FIN_TXT
Content-type: text/html

<html>
<head>
<title>SUNGRID ENGINE</title>
<META HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
Queue:&nbsp;&nbsp; <SELECT NAME="Queue">
#{message}
</SELECT>
</body>
</html>
FIN_TXT
end

exeHostQueueList=getExecutionHostQueueList()
queueList=Array.new()
numhosts=0
numTotalColas=0
queueTotalList=Array.new()
exeHostQueueList.keys.each do | executionHost |     #### Por cada HOST saco la lista de colas que tiene definidas para tener una lista de todas las colas existentes.
    queueList=exeHostQueueList[executionHost].split(",")   ### Saco la lista de colas de ese HOST
    queueList.each do | currentQueueSize |
       if ! queueTotalList.include?(currentQueueSize) then
           queueTotalList.push(currentQueueSize)
       end
       numTotalColas=numTotalColas+1
    end
    numhosts=numhosts+1
end


htmlret=""
queueTotalList.each do | targetQueueSize |
       targetQueue,targetSize=targetQueueSize.split(";")
       htmlret=htmlret+"<OPTION VALUE=\"#{targetQueue}\">#{targetQueue}</OPTION>"
end
returnHTML(htmlret)
