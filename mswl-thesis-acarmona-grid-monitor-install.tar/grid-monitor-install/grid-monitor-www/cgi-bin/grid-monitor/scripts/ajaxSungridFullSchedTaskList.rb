#!/usr/bin/ruby
# ===NAME=================================================================================================
#   ajaxSungridFullSchedTaskList.rb?DATE=YYYYMMDD&CAT=ALL&STATE=ALL&QUEUE=ALL&HOST=ALL
# ===DESCRIPTION==========================================================================================
#   Este cgi saca la lista de procesos de ejecucion diferida o planificada para una determinada fecha.
# ===LICENSE==============================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ========================================================================================================
require 'yaml'
t = Time.now
CurrentYear=t.strftime("%Y")
fecha = t.strftime("%Y%m%d")
fileConfig="/produccion/GRID/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)
PathDataFiles="#{config["configuracion"]["pathDataFiles"]}/#{CurrentYear}/tasks"
NameFileTaskList=config["configuracion"]["nameFileLista"]
NameFileStateList=config["configuracion"]["nameFileEstado"]
PathSunGridEngine=config["configuracion"]["pathGRID"]
PathLog="#{config["configuracion"]["pathLog"]}/#{CurrentYear}/cgi"
PathStyleSheet=config["configuracion"]["pathStyleSheet"]
PathJavaScripts=config["configuracion"]["pathJavaScripts"]
ENV['SGE_ROOT']=config["configuracion"]["sgeRoot"]
ENV['SGE_CELL']=config["configuracion"]["sgeCell"]
ENV['SGE_CLUSTER_NAME']=config["configuracion"]["sgeClusterName"]
ENV['SGE_QMASTER_PORT']=config["configuracion"]["sgeQmasterPort"].to_s
ENV['SGE_EXECD_PORT']=config["configuracion"]["sgeExecdPort"].to_s

def writeToLog(mensajeLog)
    t = Time.now
    fecha = t.strftime("%Y%m%d")
    fechaLog = t.strftime("%b %d %H:%M:%S")
    fileLog=PathLog+"/SunGridCgi"
    fileLog=fileLog+"-"+fecha+".log"
    logFile = File.new(fileLog, 'a+')
    logFile.puts fechaLog+" "+mensajeLog
    logFile.close
end

paramDATE,paramCAT,paramSTATE,paramQUEUE,paramHOST=ENV['QUERY_STRING'].split("&")
field,inputDATE=paramDATE.split("=")
field,inputCAT=paramCAT.split("=")
field,inputSTATE=paramSTATE.split("=")
field,inputQUEUE=paramQUEUE.split("=")
field,inputHOST=paramHOST.split("=")

if /^(\d\d\d\d)(\d\d)(\d\d)$/.match(inputDATE) then
   mesdia=$2+$3
else
   inputDATE=fecha
   mesdia=t.strftime("%m%d")
end

def getTasks(jobList,inputDATE,mesdia)
   fileLista=PathDataFiles+"/"+NameFileTaskList+"."+inputDATE
   counter = 1
   begin
	   file = File.new(fileLista, "r")
	   while (line = file.gets)
	      record=line.split("#")
              jobList['codesge'][counter]=record[0]
              jobList['typejob'][counter]=record[1]
              jobList['project'][counter]=record[2]
              jobList['nameId'][counter]=record[3] 
              ### Campo4 : 0902201123:55:01
	      if /^(\d\d)(\d\d)(\d\d\d\d)(\d\d):(\d\d):(\d\d)$/.match(record[5]) then
		   mesdiaQ=$2+$1
	      else
                   writeToLog("ERROR: getTasks: la QueueDate: #{record[5]} del fichero lista campo numero 6 NO paso expresion regular")
              end
              if record[1] == "SHELL" then
                 jobList['code'][counter]=record[4]
              else
                 jobList['code'][counter]=mesdiaQ+"-"+record[4]
              end
              jobList['queuedDate'][counter]=record[5]
              jobList['user'][counter]=record[6]
              jobList['script'][counter]=record[7]
              jobList['arg'][counter]=record[8]
              jobList['pathlog'][counter]=record[9]
              jobList['queue'][counter]=record[10].chomp
	      counter = counter + 1
	   end
	   file.close
   rescue
	error=1
   end
   return jobList,counter
end

def getStates(jobStates,inputDATE)
   fileEstado=PathDataFiles+"/"+NameFileStateList+"."+inputDATE
   begin
	   file = File.new(fileEstado, "r")
	   while (line = file.gets)
	      record=line.split("#")
	      state="P"
	      numberjob=-1
	      if /^(\D+)(\d+)$/.match(record[0]) then
	         state=$1
	         numberjob=$2
	         #puts "ESTADO #{state}, NUMBER: #{numberjob}"
	      else
	         puts "LINEA NO PASO EXPR: #{record[0]} !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1"
	      end
	      jobStates['state'][numberjob.to_i]=state
              processDates=record[5].split("-")
              jobStates['dateQueued'][numberjob.to_i]=processDates[0]
              jobStates['dateStarted'][numberjob.to_i]=processDates[1]
              jobStates['dateFinished'][numberjob.to_i]=processDates[2]
	      jobStates['queue'][numberjob.to_i]=record[6]
	      jobStates['exehost'][numberjob.to_i]=record[7]
	      jobStates['user'][numberjob.to_i]=record[8]
              if (state=="R") then
                   jobStates['timewait'][numberjob.to_i]=record[9].chomp
              else
                   jobStates['timerun'][numberjob.to_i]=record[9].chomp
              end
	   end
	   file.close
   rescue
	error=1
   end
   return jobStates
end

jobList = {"codesge"=>[],"typejob"=>[],"project"=>[],"code"=>[],"nameId"=>[],"queuedDate"=>[],"user"=>[],"script"=>[],"arg"=>[],"pathlog"=>[],"queue"=>[]}
jobStates = {"exehost"=>[],"state"=>[],"queue"=>[],"dateQueued"=>[],"dateStarted"=>[],"dateFinished"=>[],"user"=>[],"timewait"=>[],"timerun"=>[],}

jobList,numtasks=getTasks(jobList,inputDATE,mesdia)
numtasks=numtasks-1
jobState=getStates(jobStates,inputDATE)

puts <<FIN_TXT
Content-type: text/html

<html>
<a name="Init"></a>
<head>
<title>GRID - CLUSTER TEST</title>
<link rel="stylesheet" type="text/css" href="#{PathJavaScripts}/sdmenu/sdmenu.css" />
<script type="text/javascript" src="#{PathJavaScripts}/sdmenu/sdmenu.js"></script>
<link href="#{PathStyleSheet}/deployer.css?1266512930" media="screen" rel="stylesheet" type="text/css" />

<META HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">

<STYLE TYPE=\"text/css\">
.hostTable2{
        font-family: Arial, Helvetica, sans-serif;
        font-size: 12px;
        height: 1px;
        color: #727271;
        font-weight:bold;
        /*margin: 1px;*/
        padding: 1px;
        background-position: center;
        margin-top: 0px;
        margin-bottom: 0px;
        border: 0px;
        border-style: solid;
        overflow: hidden;
}

.commandsTable{
        font-size: 10px;
        text-align: center; 
        border: 0px;
        border-style: solid;
        border-color: #727271;
}

.link a, .link a:VISITED, .link a:ACTIVE, .link a:FOCUS, .link a:LINK{
        color:#316fbb;
        text-decoration:underline;
        margin: 0px;
        padding: 0px;
        background-position: center;
        margin-top: 0px;
        margin-bottom: 0px;

}

.link a:HOVER{
        color: #008fd4;
        text-decoration:underline;
}

a, a:VISITED, a:ACTIVE,a:FOCUS, a:LINK{
        color: #316fbb;
        text-decoration:none;
        margin: 0px;
        padding: 0px;
        background-position: center;
        margin-top: 0px;
        margin-bottom: 0px;

}
a:HOVER{
        color: #91278f;
        text-decoration:none;
}
</STYLE>
</HEAD>
<body bgcolor="#FFFFFF" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" alink="#980000">
FIN_TXT
puts "<table width=\"99%\" align=center cellspacing=\"0\" cellpadding=\"2\">"

####### TABLA PROCESOS #####
puts "<tr>"
 puts "<td>"
 puts "<table width=\"98%\" align=center cellspacing=\"0\" cellpadding=\"0\" border=1 BORDERCOLOR=\"#FFFFFF\" style=\'table-layout:fixed\'>"
 puts "<tr>"
 puts "<td align=center width=4%></td>"
 puts "<td align=center width=6%></td>"
 puts "<td align=center width=7%></td>"
 puts "<td align=center width=5%></td>"
 puts "<td align=center width=5%></td>"
 puts "<td align=center width=5%></td>"
 puts "<td align=center width=4%></td>"
 puts "<td align=center width=4%></td>"
 puts "<td align=center width=13%></td>"
 puts "<td align=center width=10%></td>"
 puts "<td align=left width=10%></td>"
 puts "<td align=left width=24%></td>"
 puts "<td align=center width=7%></td>"
 puts "<td align=center width=5%></td>"
 puts "<td align=center width=14%></td>"
 puts "</tr>"

 for i in (1..numtasks).to_a.reverse 
       passType=0
       passStat=0
       passQueue=0
       passHost=0
       passSched=0
       scheduleDate=""
       ### Check Type
       if inputCAT == "ALL" then passType=1 elsif jobList['typejob'][i] == inputCAT then passType=1 end
       ### Check State
       if inputSTATE == "ALL" then passStat=1 elsif jobStates['state'][i] == inputSTATE then passStat=1 end
       ### Check Queue
       if inputQUEUE == "ALL" then passQueue=1 elsif jobStates['queue'][i] == inputQUEUE then passQueue=1 end
       ### Check Host
       if inputHOST == "ALL" then passHost=1 elsif jobStates['exehost'][i] == inputHOST then passHost=1 end
       ### Check is a Scheduled Task
       if /^sched-(\S\S)(\S\S)(\S\S)(\S\S)/.match(jobList['code'][i]) then
   	    passSched=1 
	    schedMonth=$1
	    schedDay=$2
	    schedHour=$3
	    scheddMin=$4
            scheduleDate="#{schedDay}/#{schedMonth}-#{schedHour}:#{scheddMin}"
       end
       if (passType==1 && passStat==1 && passQueue==1 && passHost==1 && passSched==1) then
	  subPathLog=""
	  if /^\/produccion\/(\S+)/.match(jobList['pathlog'][i]) then
  	     subPathLog=$1
	  else
 	     writeToLog("ERROR: NOEXPR No ha sido posible sacar el path Log: #{jobList['pathlog'][i]}")
	  end
          commands="<table width=\"100%\" border=1><tr>"
          scriptName=jobList['nameId'][i]
          if jobList['typejob'][i] == "INTRA" then
	          idlog=jobList['code'][i]   ## Para ver Log necesito MMDD-NumeroIdPiscionTareaEnFicheroLista ya sea de intraenet o cron
	          cmdLog="<td class=\"commandsTable\"><a href=\"javascript:viewLogs(\'#{subPathLog}\')\">LOGS</a></td>"
                  typejob="INT"
                  backgroundcolor="#fcfdcf"
          elsif jobList['typejob'][i] == "SHELL" then
                  idlog=jobList['code'][i]   ## Para ver Log necesito MMDD-NumeroIdPiscionTareaEnFicheroLista ya sea de intraenet o cron
                  cmdLog="<td class=\"commandsTable\"><a href=\"javascript:viewLogs(\'#{subPathLog}\')\">LOGS</a></td>"
                  typejob="EXT"
		  backgroundcolor="#fcefe2"
          elsif jobList['typejob'][i] == "CRON" then
                  idlog=jobList['code'][i]   ## Para ver Log necesito MMDD-NumeroIdPiscionTareaEnFicheroLista ya sea de intraenet o cron
                  cmdLog="<td class=\"commandsTable\"><a href=\"javascript:viewLogs(\'#{subPathLog}\')\">LOGS</a></td>"
                  typejob=jobList['typejob'][i]
                  backgroundcolor="#f8fdff"
          else
                  idlog=jobList['code'][i]   ## Para ver Log necesito MMDD-NumeroIdPiscionTareaEnFicheroLista ya sea de intraenet o cron
                  cmdLog="<td class=\"commandsTable\"><a href=\"javascript:viewLogs(\'#{subPathLog}\')\">LOGS</a></td>"
		  typejob=jobList['typejob'][i]
                  backgroundcolor="#fffbb3"
          end
	  estado="--"
	  ####idjob=jobList['code'][i].split("-")
          queuedTime="--"
	  runTimeProc="--"
	  finishedTime="--"
	  bgcolor="grey"
          textcolor="#000000"
          timeWait="--"
          timeRun="--" 
	  if  jobStates['state'][i] == "U" then
  	       estado="<img src=\"#{config["configuracion"]["pathImages"]}/question-icon.png\" width=\"15\" height=\"15\">"
	       bgcolor="#f83080"
	       #textcolor="#f83080"
	       textcolor="#df7603"
               commands=commands+cmdLog
	  elsif  jobStates['state'][i] == "R" then 
		estado="<img src=\"#{config["configuracion"]["pathImages"]}/run-icon3.png\" width=\"20\" height=\"20\">"
		##bgcolor="#0040c1"
		bgcolor="#1f3f74"
		commands=commands+cmdLog+"<td class=\"commandsTable\"><a href=\"javascript:killProcess(\'#{jobList['codesge'][i]}\',\'#{inputDATE}\')\">STOP</a></td>"
		 textcolor="#1f3f74"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateQueued'][i]) then queuedTime=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateQueued'][i]) then queuedTime=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateStarted'][i]) then runTimeProc=$1 end
                timeWait=jobStates['timewait'][i]
	  elsif  jobStates['state'][i] == "D" then 
		estado="<img src=\"#{config["configuracion"]["pathImages"]}/icon-ok.jpg\" width=\"15\" height=\"15\">"
                commands=commands+cmdLog
		bgcolor="#1f4b24"
                textcolor="#424242"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateQueued'][i]) then queuedTime=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateStarted'][i]) then runTimeProc=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateFinished'][i]) then finishedTime=$1 end
                timeWait=jobStates['timewait'][i]
                timeRun=jobStates['timerun'][i]
	  elsif  jobStates['state'][i] == "F" then 
		estado="<img src=\"#{config["configuracion"]["pathImages"]}/icon-error.jpg\" width=\"15\" height=\"15\">"
		bgcolor="red"
                commands=commands+cmdLog
		textcolor="red"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateQueued'][i]) then queuedTime=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateStarted'][i]) then runTimeProc=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateFinished'][i]) then finishedTime=$1 end
                timeWait=jobStates['timewait'][i]
                timeRun=jobStates['timerun'][i]
	  elsif  jobStates['state'][i] == "N" then 
		estado="UNKNOWN"	
		bgcolor="black"
                commands=commands+cmdLog
	  elsif  jobStates['state'][i] == "A" then 
                estado="<img src=\"#{config["configuracion"]["pathImages"]}/notice-error.jpg\" width=\"15\" height=\"15\">"
		bgcolor="red"
                textcolor="red"
                timeWait=jobStates['timewait'][i]
                timeRun=jobStates['timerun'][i]
                commands=commands+cmdLog
	  elsif  jobStates['state'][i] == "C" then 
		estado="<img src=\"#{config["configuracion"]["pathImages"]}/notice-notavailable-2.jpg\" width=\"15\" height=\"15\">"
		bgcolor="red"
		textcolor="orange"
                commands=commands+cmdLog
          elsif  jobStates['state'][i] == "FH" then
                estado="<img src=\"#{config["configuracion"]["pathImages"]}/fire-server-icon3.png\" width=\"15\" height=\"15\">"
                bgcolor="red"
                commands=commands+cmdLog+"<td class=\"commandsTable\"><a href=\"javascript:RelaunchProcess(\'#{jobList['codesge'][i]}\',\'#{inputDATE}\')\">RE-QUEUE</a></td>"
                textcolor="red"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateQueued'][i]) then queuedTime=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateStarted'][i]) then runTimeProc=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateFinished'][i]) then finishedTime=$1 end
                timeWait=jobStates['timewait'][i]
                timeRun=jobStates['timerun'][i]
          elsif  jobStates['state'][i] == "QA" then
                estado="<img src=\"#{config["configuracion"]["pathImages"]}/queued-icon.png\" width=\"15\" height=\"15\">"
                commands=commands+"<td class=\"commandsTable\"><a href=\"javascript:cancelProcess(\'#{jobList['codesge'][i]}\',\'#{inputDATE}\')\">CANCEL</a></td><td class=\"commandsTable\"><a href=\"javascript:changeQueue(\'#{jobList['codesge'][i]}\',\'#{inputDATE}\')\">CHANGE-Q</a></td>"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateQueued'][i]) then queuedTime=$1 end
          elsif  jobStates['state'][i] == "QE" then
		textcolor="red"
                estado="<img src=\"#{config["configuracion"]["pathImages"]}/queued-error-icon.jpg\" width=\"15\" height=\"15\">"
		commands=commands+cmdLog+"<td class=\"commandsTable\"><a href=\"javascript:RelaunchProcess(\'#{jobList['codesge'][i]}\',\'#{inputDATE}\')\">RE-QUEUE</a></td>"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateQueued'][i]) then queuedTime=$1 end
          elsif  jobStates['state'][i] == "RL" then
                textcolor="blue"
                estado="<img src=\"#{config["configuracion"]["pathImages"]}/relaunched-icon.jpg\" width=\"15\" height=\"15\">"
                commands=commands+cmdLog
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateQueued'][i]) then queuedTime=$1 end
          else
                estado="<img src=\"#{config["configuracion"]["pathImages"]}/enter-icon.png\" width=\"15\" height=\"15\">"
		commands=commands+"<td class=\"commandsTable\"><img src=\"#{config['configuracion']['pathImages']}/enter-icon.png\" width=\"15\" height=\"15\" valign=\"MIDDLE\" border=0></td>"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(jobStates['dateQueued'][i]) then queuedTime=$1 end
          end

          showNum="<P style=\"font-size: 8pt; color: #{textcolor}\">#{i}</P>"
          showCodeSge="<P style=\"font-size: 8pt; color: #{textcolor}\">#{jobList['codesge'][i]}</P>"
          showCode="<P style=\"font-size: 8pt; color: #{textcolor}\">#{scheduleDate}</P>"
          showType="<P style=\"font-size: 8pt; color: #{textcolor}\">#{typejob}</P>"
          showUser="<P style=\"font-size: 8pt; color: #{textcolor}\">#{jobList['user'][i]}</P>"
          showScript="<P style=\"font-size: 8pt; color: #{textcolor};text-align: left\">#{scriptName}</P>"
          showProject="<P style=\"font-size: 8pt; color: #{textcolor};text-align: left\">#{jobList['project'][i]}</P>"
          showArg="<P style=\"font-size: 8pt; color: #{textcolor}\">#{jobList['arg'][i]}</P>"
          showExeHost="<P style=\"font-size: 8pt; color: #{textcolor}\">#{jobStates['exehost'][i]}</P>"
          showQueue="<P style=\"font-size: 8pt; color: #{textcolor}\">#{jobStates['queue'][i]}</P>"
          showQueuedTime="<P style=\"font-size: 8pt; color: #{textcolor}\">#{queuedTime}</P>"
          showRunTimeProc="<P style=\"font-size: 8pt; color: #{textcolor}\">#{runTimeProc}</P>"
          showFinishedTime="<P style=\"font-size: 8pt; color: #{textcolor}\">#{finishedTime}</P>"
          showTimeWait="<P style=\"font-size: 8pt; color: #{textcolor}\">#{timeWait}</P>"
          showTimeRun="<P style=\"font-size: 8pt; color: #{textcolor}\">#{timeRun}</P>"

          puts "<tr style=\"background-color: #{backgroundcolor};\">"
          puts "<td class=\"hostTable\" align=center>#{showNum}</td>"
          if jobStates['state'][i] == "QE" || jobStates['state'][i] == "RL" then
                puts "<td class=\"hostTable\" align=center>#{jobList['codesge'][i]}</td>"
	  else
		puts "<td class=\"hostTable\" align=center><a href=\"javascript:JobInfo(#{jobList['codesge'][i]},#{inputDATE},\'#{jobStates['state'][i]}\')\">#{jobList['codesge'][i]}</a></td>"
	  end
          puts "<td class=\"hostTable\" align=center>#{showCode}</td>"
          puts "<td class=\"hostTable\" align=center>#{showQueuedTime}</td>"
          puts "<td class=\"hostTable\" align=center>#{showRunTimeProc}</td>"
          puts "<td class=\"hostTable\" align=center>#{showFinishedTime}</td>"
          puts "<td class=\"hostTable\" align=center>#{timeWait}</td>"
          puts "<td class=\"hostTable\" align=center>#{timeRun}</td>"
          puts "<td class=\"hostTable\" align=center>#{showUser}</td>"
          puts "<td class=\"hostTable\" align=center>#{showQueue}</td>"
          puts "<td class=\"hostTable\" align=left>#{showProject}</td>"
          puts "<td class=\"hostTable\" align=left>#{showScript}</td>"
          puts "<td class=\"hostTable\" align=center>#{showExeHost}</td>"
          puts "<td class=\"hostTable\" align=center><P style=\"font-size: 8pt; color: #{bgcolor}\">#{estado}</P></td>"
          puts "<td class=\"hostTable\" align=center>#{commands}</tr></table></td>"
     puts "</tr>"
     end ##### end Pass Check

 end  ###end_for_each_task
 puts "</table>"
 ############ END TABLA DE PROCESOS ################

 puts "</td>"

puts "</tr>"
puts "</table>"
puts "<br><br><br>"
puts "</body>"
puts "</html>"


