#!/usr/bin/ruby
# ===NAME==========================================================================================
#    ajaxSungridRunningTasks.rb
# ===DESCRIPTION===================================================================================
#    Devuelve en html el porcentaje de ocupacion (Jobs en estado RUNNING) de una cola en un determinado host o en todos los que pertenecen al Grid
#    QUERY_STRING=queue=b&host=ALL&numform=12&numhosts=2
#      RETURN: procesos waiting-numformulario-procesos Runinn-capacidad
# ===LICENSE=======================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ==================================================================================================
require 'yaml'
t = Time.now
CurrentYear=t.strftime("%Y")
fileConfig="/opt/grid-monitor/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)
PathMonitor="#{config["configuracion"]["pathDataFiles"]}/#{CurrentYear}/monitor"
NameFileMonitorQueues=config["configuracion"]["nameFileMonitorQueues"]
PathSunGridEngine=config["configuracion"]["pathGRID"]

ENV['SGE_ROOT']=config["configuracion"]["sgeRoot"]
ENV['SGE_CELL']=config["configuracion"]["sgeCell"]
ENV['SGE_CLUSTER_NAME']=config["configuracion"]["sgeClusterName"]
ENV['SGE_QMASTER_PORT']=config["configuracion"]["sgeQmasterPort"].to_s
ENV['SGE_EXECD_PORT']=config["configuracion"]["sgeExecdPort"].to_s

def getExecutionHostQueueList()
        #[root@deltaweb 2010]# qhost  -q
        #HOSTNAME                ARCH         NCPU  LOAD  MEMTOT  MEMUSE  SWAPTO  SWAPUS
        #-------------------------------------------------------------------------------
        #global                  -               -     -       -       -       -       -
        #delta0                  lx24-amd64      1  0.00    1.0G  145.4M    2.0G     0.0
        #   i                    BIP   0/0/5
        #   k                    BIP   0/0/5
        #delta1                  lx24-amd64      1  0.00    1.0G  112.1M    2.0G     0.0
        #   i                    BIP   0/0/5
        #   n                    BIP   0/0/1
	#delta0                  lx24-amd64      2     -    4.0G       -    4.0G       -
	#   l                    BIP   0/0/1         au   : COLA NO DISPONIBLE
	#   r                    BIP   0/0/1         au
        #  qhost sin parametros da esto
        #HOSTNAME                ARCH         NCPU  LOAD  MEMTOT  MEMUSE  SWAPTO  SWAPUS
        #-------------------------------------------------------------------------------
        #global                  -               -     -       -       -       -       -
        #delta0                  lx24-amd64      1     -    1.0G       -    2.0G       -
        #delta1                  lx24-amd64      1  0.00    1.0G   82.6M    2.0G     0.0
   exeHostQueueList=Hash.new("")
   currentHost=""
   outPut=`#{PathSunGridEngine}/bin/lx24-amd64/qhost -q`
   outPut.each do | linea |
       if /^(\S+)\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+$/.match(linea) then
           if ($1 != "global" && $1 != "HOSTNAME")then
                currentHost=$1
           end
        elsif /^\s+(\S+)\s+\S+\s+\d+\/\d+\/(\d+)\s*/.match(linea) then
           if exeHostQueueList[currentHost]=="" then
                  exeHostQueueList[currentHost]=$1+";"+$2
           else
                  exeHostQueueList[currentHost]="#{exeHostQueueList[currentHost]},#{$1};#{$2}"
           end
       end
   end
   return exeHostQueueList
end

##### getExecutionHostState : Obtiene el estado de un Execution Host: UP/DOWN
def getExecutionHostState(targetHost)
   hostState="UP"
   outPut=`#{PathSunGridEngine}/bin/lx24-amd64/qhost`
   outPut.each do | linea |
       if /^(\S+)\s+\S+\s+\S+\s+(\S+)\s+\S+\s+\S+\s+\S+\s+\S+$/.match(linea) then
           if $1 == targetHost then
              if $2 == "-" then
                hostState="DOWN"
              end
           end
       end
   end
   return hostState
end

def returnHTML(message,inputNumForm,numOccupied,sizeQueue)
puts <<FIN_TXT
Content-type: text/html

#{message}-#{inputNumForm}-#{numOccupied}-#{sizeQueue}
FIN_TXT
end

if ENV['QUERY_STRING']==nil then
     returnHTML("ERROR",0,0,0)
else
     paramQueue,paramHost,paramNumForm,paramNumHosts=ENV['QUERY_STRING'].split("&")
     field,inputQueue=paramQueue.split("=")
     field,inputHost=paramHost.split("=")
     field,inputNumForm=paramNumForm.split("=")
     #field,inputNumHosts=paramNumHosts.split("=")

     ### Obtengo la lista de ExecutionHosts
     exeHostQueueList=getExecutionHostQueueList()

     numhosts=0
     numhostsUP=0
     queueTotalList=Array.new()

     exeHostQueueList.keys.each do | executionHost |     #### Por cada HOST
         queueList=exeHostQueueList[executionHost].split(",")   ### Saco la lista de colas de ese HOST
         queueList.each do | currentQueueSize |
           if ! queueTotalList.include?(currentQueueSize) then
               queueTotalList.push(currentQueueSize)
           end
         end
        if (getExecutionHostState(executionHost)=="UP") then numhostsUP=numhostsUP+1 end
        numhosts=numhosts+1
     end
     inputNumHosts=numhostsUP

     ### Numero de procesos encolados en una cola determinada.
     fileDat=PathMonitor+"/"+NameFileMonitorQueues
     file = File.new(fileDat, "r")
     if File.zero?( fileDat ) then
        sleep 2 
     end

     numOccupied=0
     sizeQueue=0
     numProcQueued=0
     statusQ="NONE"
     record=Array.new()
     while (line = file.gets)
        line=line.chomp
        record=line.split("\#")
        if record[0] == inputQueue then
               sizeQueue=record[1]
               hostDataList=Array.new()
               hostDataList=record[4].split("&")
               hostDataList.each do | tokenHostData |  ### Por cada host que este UP
                       nameHost,dataHost=tokenHostData.split("=")
                       numRunTask,statusQueue=dataHost.split(",")
                       if inputHost=="ALL" then
	                    numOccupied=record[3]
                            if statusQueue=="RUN" then
                                statusQ=statusQueue
                            elsif statusQ!="RUN"
                                statusQ=statusQueue
                            end
                       elsif nameHost==inputHost then
                             #puts "Si #{nameHost} IGUAL a #{inputHost} entonces: Cola:#{inputQueue} Estado:#{statusQueue}"
			    numOccupied=numRunTask
                            statusQ=statusQueue
                       end
               end 				       ### end por cada host
        end ### Fin registro encontrado.
     end
     file.close
     percent=0
    if statusQ=="RUN" then
	     if inputHost=="ALL" then
	              percent=(numOccupied.to_i * 100) / (sizeQueue.to_i * inputNumHosts.to_i)
                      sizeQueue=sizeQueue.to_i * inputNumHosts.to_i
	     else
		      percent=(numOccupied.to_i * 100) / (sizeQueue.to_i)
	     end
     else
          sizeQueue=0
 	  percent=0
	  numOccupied=0
     end
     returnHTML(percent,inputNumForm,numOccupied,sizeQueue)
end
