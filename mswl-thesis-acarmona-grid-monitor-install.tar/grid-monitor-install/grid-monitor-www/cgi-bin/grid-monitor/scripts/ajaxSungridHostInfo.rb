#!/usr/bin/ruby
# ===NAME==========================================================================================
#    ajaxSungridHostInfo.rb
# ===DESCRIPTION===================================================================================
#    Devuelve informacion sobre el estado de un Host.
#    QUERY_STRING=host=delta0&cmd=CPU|MEM|SWAP
# ===LICENSE=======================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ==================================================================================================
require 'yaml'

t = Time.now
CurrentYear=t.strftime("%Y")
fileConfig="/opt/grid-monitor/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)

PathMonitor="#{config["configuracion"]["pathDataFiles"]}/#{CurrentYear}/monitor"
NameFileMonitorHosts=config["configuracion"]["nameFileMonitorHosts"]

sizeFont="8"
colorFont="grey"
weightFont="normal"
backgroundColor="#e8ebf6"

def returnHTML(message,sizeFont,colorFont,weightFont,backgroundColor)
puts <<FIN_TXT
Content-type: text/html

<html>
<head>
<title>SUNGRID ENGINE</title>
<META HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
<div style="font-size: #{sizeFont}pt;font-weight: #{weightFont} ; color: #{colorFont};background-color: #{backgroundColor}">#{message}</div>
</body>
</html>
FIN_TXT
end

##He quitado:<P style="font-size: #{sizeFont}pt;font-weight: #{weightFont} ; color: #{colorFont};background-color: #{backgroundColor}">#{message}</P> 
## Me salian columnas muy grandes.

if ENV['QUERY_STRING']==nil then 
	returnHTML("ERROR")
else
     paramHost,paramCmd=ENV['QUERY_STRING'].split("&")
     field,inputHost=paramHost.split("=")
     field,inputCmd=paramCmd.split("=")

     fileDat=PathMonitor+"/"+NameFileMonitorHosts
     file = File.new(fileDat, "r")
     if File.zero?( fileDat ) then
        sleep 2
     end
     loadCpu=""
     memUsed=""
     swapUsed=""
     while (line = file.gets)
        line=line.chomp
        record=line.split("#")
        if record[0] == inputHost then
           loadCpu=record[1]
           memUsed=record[2]
           swapUsed=record[3]
        end
     end
     file.close
     if inputCmd=="CPU" then result=loadCpu
           if loadCpu.to_i >= 10 then
                colorFont="red"
                weightFont="bold"
           end
           if loadCpu == "DOWN" then
                sizeFont="10"
                colorFont="white"
                backgroundColor="#e82634"
                weightFont="bold"
                result="<blink>#{loadCpu}</blink>"
           end
     elsif inputCmd=="MEM" then result=memUsed+"%"
           if memUsed.to_i > 89 then 
                colorFont="red"
                weightFont="bold"
           end
           if memUsed == "DOWN" then
                sizeFont="10"
                colorFont="white"
                backgroundColor="#e82634"
                weightFont="bold"
                result="<blink>#{memUsed}</blink>"
           end
     elsif inputCmd=="SWAP" then result=swapUsed+"%" 
           if swapUsed.to_i > 60 then
               colorFont="red"
               weightFont="bold"
           end
           if swapUsed == "DOWN" then
                sizeFont="10"
                colorFont="white"
		backgroundColor="#e82634"
                weightFont="bold"
                result="<blink>#{swapUsed}</blink>"
           end
     end
     returnHTML(result,sizeFont,colorFont,weightFont,backgroundColor)
end
