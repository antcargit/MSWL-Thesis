#!/usr/bin/ruby
# ===NAME==========================================================================================
#    ajaxSungridShellList.rb?Project=CONTAVAL
# ===DESCRIPTION===================================================================================
#    Este cgi devuelve una lista con las shells que son ejecutables de un proyecto.
# ===LICENSE=======================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ==================================================================================================
require 'yaml'

fileConfig="/opt/grid-monitor/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)

PathSunGridEngine=config["configuracion"]["pathGRID"]

def returnHTML(message)
puts <<FIN_TXT
Content-type: text/html

<html>
<head>
<title>SUNGRID ENGINE</title>
<META HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
Shells: &nbsp;&nbsp;<SELECT NAME="Shell">
#{message}
</SELECT>
</body>
</html>
FIN_TXT
end

if ENV['QUERY_STRING']==nil then 
        returnHTML("ERROR")
else
     field,inputProject=ENV['QUERY_STRING'].split("=")
     htmlret=""
     outPut=`ls /produccion/#{inputProject}/bin`
     outPut.each do | shellScript |
       shellScript=shellScript.chomp
       shellScriptFullPath="/produccion/#{inputProject}/bin/#{shellScript}"
       if File.executable?(shellScriptFullPath) && File.file?(shellScriptFullPath)  then
          htmlret=htmlret+"<OPTION VALUE=\"#{shellScript}\">#{shellScript}</OPTION>"
       end
     end
     returnHTML(htmlret)
end
