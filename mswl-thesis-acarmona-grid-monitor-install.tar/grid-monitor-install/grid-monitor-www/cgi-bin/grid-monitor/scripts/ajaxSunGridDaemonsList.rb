#!/usr/bin/ruby
# ===NAME==========================================================================================
#   ajaxSunGridDaemonsList.rb?DATE=YYYYMMDD
# ===LICENSE=======================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ==================================================================================================
require 'yaml'
t = Time.now
CurrentYear=t.strftime("%Y")
fecha = t.strftime("%Y%m%d")
fileConfig="/opt/grid-monitor/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)
PathDataFiles="#{config["configuracion"]["pathDataFiles"]}/#{CurrentYear}/tasks"
PathEtc=config["configuracion"]["pathEtc"]
NameFileDaemonsList=config["configuracion"]["nameFileDaemonsLista"]
NameFileDaemonState=config["configuracion"]["nameFileDaemonsEstado"]
PathSunGridEngine=config["configuracion"]["pathGRID"]
PathLog="#{config["configuracion"]["pathLog"]}/#{CurrentYear}/cgi"
PathStyleSheet=config["configuracion"]["pathStyleSheet"]
PathJavaScripts=config["configuracion"]["pathJavaScripts"]
ENV['SGE_ROOT']=config["configuracion"]["sgeRoot"]
ENV['SGE_CELL']=config["configuracion"]["sgeCell"]
ENV['SGE_CLUSTER_NAME']=config["configuracion"]["sgeClusterName"]
ENV['SGE_QMASTER_PORT']=config["configuracion"]["sgeQmasterPort"].to_s
ENV['SGE_EXECD_PORT']=config["configuracion"]["sgeExecdPort"].to_s
aux,inputDATE=ENV['QUERY_STRING'].split("=")
if /^(\d\d\d\d)(\d\d)(\d\d)$/.match(inputDATE) then
   mesdia=$2+$3
else
   inputDATE=fecha
   mesdia=t.strftime("%m%d")
end

def getDaemonsList(daemonList)
   error=0
   counter=0
   fileLista=PathEtc+"/"+NameFileDaemonsList
   if File.exists?(fileLista) then
     counter = 1
     begin 
           file = File.new(fileLista, "r")
           while (line = file.gets)
                line=line.chomp
                record=line.split("#")
                daemonList['project'][counter]=record[0]
                daemonList['name'][counter]=record[1]
                daemonList['type'][counter]=record[2]
                daemonList['user'][counter]=record[3]
                daemonList['start'][counter]=record[4]
                daemonList['stop'][counter]=record[5].chomp
                counter = counter + 1
           end
           file.close
     rescue
          writeToLog("WARNING: getDaemonsList : No se ha podido abrir el fichero Lista de Demonios: #{fileLista}")
          error=1
     end
   else
       error=1
   end
   return counter,error
end

def writeToLog(mensajeLog)
    t = Time.now
    fecha = t.strftime("%Y%m%d")
    fechaLog = t.strftime("%b %d %H:%M:%S")
    fileLog=PathLog+"/SunGridCgi"
    fileLog=fileLog+"-"+fecha+".log"
    logFile = File.new(fileLog, 'a+')
    logFile.puts fechaLog+" "+mensajeLog
    logFile.close
end

def getDaemonsStates(daemonStates,inputDATE)
   fileEstado=PathDataFiles+"/"+NameFileDaemonState+"."+inputDATE
   begin
	   file = File.new(fileEstado, "r")
	   while (line = file.gets)
	      record=line.split("#")
	      state="P"
	      numberjob=-1
	      if /^(\D+)(\d+)$/.match(record[0]) then
	         state=$1
	         numberjob=$2
	         #puts "ESTADO #{state}, NUMBER: #{numberjob}"
	      else
                 writeToLog("ERROR: getDaemonsStates: NO-EXPR: #{record[0]}")
	      end
	      daemonStates['state'][numberjob.to_i]=state
	      daemonStates['sgeid'][numberjob.to_i]=record[1]
              processDates=record[5].split("-")
              daemonStates['dateQueued'][numberjob.to_i]=processDates[0]
              daemonStates['dateStarted'][numberjob.to_i]=processDates[1]
              daemonStates['dateFinished'][numberjob.to_i]=processDates[2]
	      daemonStates['queue'][numberjob.to_i]=record[6]
	      daemonStates['exehost'][numberjob.to_i]=record[7]
	      daemonStates['exeOK'][numberjob.to_i]=record[8]
	      daemonStates['exeERROR'][numberjob.to_i]=record[9].chomp
	   end
	   file.close
   rescue
	error=1
   end
   return daemonStates
end

daemonList = {
    "project"=>[],
    "name"=>[],
    "type"=>[],
    "user"=>[],
    "start"=>[],
    "stop"=>[],
}

daemonStates = {
            "sgeid"=>[], 
	    "state"=>[],
	    "queue"=>[],
	    "dateQueued"=>[],
	    "dateStarted"=>[],
	    "dateFinished"=>[],
	    "exehost"=>[],
	    "exeOK"=>[],
	    "exeERROR"=>[],
}

numtasks=0
numtasks,error=getDaemonsList(daemonList)
numtasks=numtasks - 1

daemonStates=getDaemonsStates(daemonStates,inputDATE)

puts <<FIN_TXT
Content-type: text/html

<html>
<a name="Init"></a>
<head>
<title>GRID - CLUSTER TEST</title>
<link rel="stylesheet" type="text/css" href="#{PathJavaScripts}/sdmenu/sdmenu.css" />
<script type="text/javascript" src="#{PathJavaScripts}/sdmenu/sdmenu.js"></script>
<link href="#{PathStyleSheet}/deployer.css?1266512930" media="screen" rel="stylesheet" type="text/css" />

<META HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">

<STYLE TYPE=\"text/css\">
.hostTable2{
        font-family: Arial, Helvetica, sans-serif;
        font-size: 12px;
        height: 1px;
        color: #727271;
        font-weight:bold;
        /*margin: 1px;*/
        padding: 1px;
        background-position: center;
        margin-top: 0px;
        margin-bottom: 0px;
        border: 0px;
        border-style: solid;
        overflow: hidden;
}

.commandsTable{
        font-size: 10px;
        text-align: center; 
        border: 0px;
        border-style: solid;
        border-color: #727271;
}

.link a, .link a:VISITED, .link a:ACTIVE, .link a:FOCUS, .link a:LINK{
        color:#316fbb;
        text-decoration:underline;
        margin: 0px;
        padding: 0px;
        background-position: center;
        margin-top: 0px;
        margin-bottom: 0px;

}

.link a:HOVER{
        color: #008fd4;
        text-decoration:underline;
}

a, a:VISITED, a:ACTIVE,a:FOCUS, a:LINK{
        color: #316fbb;
        /* color:#878787; */
        text-decoration:none;
        margin: 0px;
        padding: 0px;
        background-position: center;
        margin-top: 0px;
        margin-bottom: 0px;

}
a:HOVER{
        color: #91278f;
        text-decoration:none;
}
</STYLE>
</HEAD>
<body bgcolor="#FFFFFF" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" alink="#980000">
FIN_TXT
puts "<table width=\"99%\" align=center cellspacing=\"0\" cellpadding=\"0\">"
puts "<tr><td>&nbsp;</td></tr>"

puts "<tr>"
 puts "<td>"
 puts "<table width=\"95%\" align=center cellspacing=\"0\" cellpadding=\"0\" border=1 BORDERCOLOR=\"#FFFFFF\" style=\'table-layout:fixed\'>"
 puts "<tr>"
 puts "<td class=\"hostTableTitle\" align=center width=4%>Num</td>"
 puts "<td class=\"hostTableTitle\" align=center width=10%>SgeId</td>"
 puts "<td class=\"hostTableTitle\" align=center width=5%>Queued</td>"
 puts "<td class=\"hostTableTitle\" align=center width=5%>Running</td>"
 puts "<td class=\"hostTableTitle\" align=center width=5%>Finished</td>"
 puts "<td class=\"hostTableTitle\" align=center width=5%>User</td>"
 puts "<td class=\"hostTableTitle\" align=center width=11%>Queue</td>"
 puts "<td class=\"hostTableTitle\" align=center width=15%>Project</td>"
 puts "<td class=\"hostTableTitle\" align=left width=27%>Task</td>"
 puts "<td class=\"hostTableTitle\" align=center width=10%>Ok</td>"
 puts "<td class=\"hostTableTitle\" align=center width=10%>Error</td>"
 puts "<td class=\"hostTableTitle\" align=center width=10%>Host</td>"
 puts "<td class=\"hostTableTitle\" align=center width=5%>State</td>"
 puts "<td class=\"hostTableTitle\" align=center width=16%>Commands</td>"
 puts "</tr>"
 for i in (1..numtasks)
          commands="<table width=\"100%\" border=1><tr>"
          cmdLog="<td class=\"commandsTable\"><a href=\"javascript:viewLogs(\'#{daemonStates['sgeid'][i]}\')\">LOGS</a></td>"
	  backgroundcolor="#f8fdff"
	  estado="--"
          queuedTime="--"
	  runTimeProc="--"
	  finishedTime="--"
	  bgcolor="grey"
          textcolor="#000000"
          timeWait="--"
          timeRun="--" 
	  if  daemonStates['state'][i] == "U" then
  	       estado="<img src=\"#{config["configuracion"]["pathImages"]}/question-icon.png\" width=\"15\" height=\"15\">"
	       bgcolor="#f83080"
	       textcolor="#df7603"
               commands=commands+cmdLog
	  elsif  daemonStates['state'][i] == "R" then 
		estado="<img src=\"#{config["configuracion"]["pathImages"]}/run-icon3.png\" width=\"20\" height=\"20\">"
		bgcolor="#1f3f74"
		commands=commands+cmdLog+"<td class=\"commandsTable\"><a href=\"javascript:killProcess(\'#{daemonStates['sgeid'][i]}\',\'#{inputDATE}\')\">STOP</a></td>"
		 textcolor="#1f3f74"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateQueued'][i]) then queuedTime=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateQueued'][i]) then queuedTime=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateStarted'][i]) then runTimeProc=$1 end
	  elsif  daemonStates['state'][i] == "D" then 
		estado="<img src=\"#{config["configuracion"]["pathImages"]}/icon-ok.jpg\" width=\"15\" height=\"15\">"
                commands=commands+cmdLog
		bgcolor="#1f4b24"
                textcolor="#424242"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateQueued'][i]) then queuedTime=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateStarted'][i]) then runTimeProc=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateFinished'][i]) then finishedTime=$1 end
	  elsif  daemonStates['state'][i] == "F" then 
		estado="<img src=\"#{config["configuracion"]["pathImages"]}/icon-error.jpg\" width=\"15\" height=\"15\">"
		bgcolor="red"
                commands=commands+cmdLog
		textcolor="red"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateQueued'][i]) then queuedTime=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateStarted'][i]) then runTimeProc=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateFinished'][i]) then finishedTime=$1 end
          elsif  daemonStates['state'][i] == "QE" then
                estado="<img src=\"#{config["configuracion"]["pathImages"]}/icon-error.jpg\" width=\"15\" height=\"15\">"
                bgcolor="red"
                commands=commands+cmdLog
                textcolor="red"
	  elsif  daemonStates['state'][i] == "N" then 
		estado="UNKNOWN"	
		bgcolor="black"
                commands=commands+cmdLog
	  elsif  daemonStates['state'][i] == "A" then 
                estado="<img src=\"#{config["configuracion"]["pathImages"]}/notice-error.jpg\" width=\"15\" height=\"15\">"
		estado="ABORTED"
		bgcolor="red"
                textcolor="red"
                commands=commands+"<td class=\"commandsTable\">&nbsp;&nbsp;</td>"
	  elsif  daemonStates['state'][i] == "C" then 
		estado="<img src=\"#{config["configuracion"]["pathImages"]}/notice-notavailable.jpg\" width=\"15\" height=\"15\">"
		bgcolor="red"
		textcolor="orange"
                commands=commands+"<td class=\"commandsTable\">&nbsp;&nbsp;</td>"
          elsif  daemonStates['state'][i] == "FH" then
                estado="<img src=\"#{config["configuracion"]["pathImages"]}/fire-server-icon3.png\" width=\"15\" height=\"15\">"
                bgcolor="red"
                commands=commands+cmdLog+"<td class=\"commandsTable\"><a href=\"javascript:RelaunchProcess(\'#{daemonStates['sgeid'][i]}\',\'#{inputDATE}\')\">RE-QUEUE</a></td>"
                textcolor="red"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateQueued'][i]) then queuedTime=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateStarted'][i]) then runTimeProc=$1 end
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateFinished'][i]) then finishedTime=$1 end
          elsif  daemonStates['state'][i] == "QA" then
                estado="<img src=\"#{config["configuracion"]["pathImages"]}/queued-icon.png\" width=\"15\" height=\"15\">"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateQueued'][i]) then queuedTime=$1 end
                commands=commands+"<img src=\"#{config["configuracion"]["pathImages"]}/transp.gif\" width=\"15\" height=\"15\">"
          else
                estado="<img src=\"#{config["configuracion"]["pathImages"]}/transp.gif\" width=\"15\" height=\"15\">"
		commands=commands+"<td class=\"commandsTable\"><img src=\"#{config['configuracion']['pathImages']}/transp.gif\" width=\"15\" height=\"15\" valign=\"MIDDLE\" border=0></td>"
                if /^\d\d\d\d\d\d\d\d(\d\d:\d\d):\d\d$/.match(daemonStates['dateQueued'][i]) then queuedTime=$1 end
          end

          showNum="<P style=\"font-size: 8pt; color: #{textcolor}\">#{i}</P>"
          showSgeID="<P style=\"font-size: 8pt; color: #{textcolor}\">#{daemonStates['sgeid'][i]}</P>"
          showUser="<P style=\"font-size: 8pt; color: #{textcolor}\">#{daemonList['user'][i]}</P>"
          showProject="<P style=\"font-size: 8pt; color: #{textcolor};text-align: left\">#{daemonList['project'][i]}</P>"
          showScript="<P style=\"font-size: 8pt; color: #{textcolor};text-align: left\">#{daemonList['name'][i]}</P>"
          showExeHost="<P style=\"font-size: 8pt; color: #{textcolor}\">#{daemonStates['exehost'][i]}</P>"
          showQueue="<P style=\"font-size: 8pt; color: #{textcolor}\">#{daemonStates['queue'][i]}</P>"
          showQueuedTime="<P style=\"font-size: 8pt; color: #{textcolor}\">#{queuedTime}</P>"
          showRunTimeProc="<P style=\"font-size: 8pt; color: #{textcolor}\">#{runTimeProc}</P>"
          showFinishedTime="<P style=\"font-size: 8pt; color: #{textcolor}\">#{finishedTime}</P>"
          showNumExeOK="<P style=\"font-size: 8pt; color: #{textcolor}\">#{daemonStates['exeOK'][i]}</P>"
          showNumExeERROR="<P style=\"font-size: 8pt; color: #{textcolor}\">#{daemonStates['exeERROR'][i]}</P>"

          puts "<tr style=\"background-color: #{backgroundcolor};\">"
          puts "<td class=\"hostTable\" align=center>#{showNum}</td>"
          puts "<td class=\"hostTable\" align=center><a href=\"javascript:JobInfo(#{daemonStates['sgeid'][i]},#{inputDATE},\'#{daemonStates['state'][i]}\')\">#{daemonStates['sgeid'][i]}</a></td>"
          puts "<td class=\"hostTable\" align=center>#{showQueuedTime}</td>"
          puts "<td class=\"hostTable\" align=center>#{showRunTimeProc}</td>"
          puts "<td class=\"hostTable\" align=center>#{showFinishedTime}</td>"
          puts "<td class=\"hostTable\" align=center>#{showUser}</td>"
          puts "<td class=\"hostTable\" align=center>#{showQueue}</td>"
          puts "<td class=\"hostTable\" align=left>#{showProject}</td>"
          puts "<td class=\"hostTable\" align=left>#{showScript}</td>"
          puts "<td class=\"hostTable\" align=center>#{showNumExeOK}</td>"
          puts "<td class=\"hostTable\" align=center>#{showNumExeERROR}</td>"
          puts "<td class=\"hostTable\" align=center>#{showExeHost}</td>"
          puts "<td class=\"hostTable\" align=center><P style=\"font-size: 8pt; color: #{bgcolor}\">#{estado}</P></td>"
          puts "<td class=\"hostTable\" align=center>#{commands}</tr></table></td>"
     puts "</tr>"
 end  ###end_for_each_task
 puts "</table>"
 puts "</td>"
puts "</tr>"
puts "</table>"
puts "</body>"
puts "</html>"


