#!/usr/bin/ruby
# ===NAME==========================================================================================
#   ajaxSungridQueuedTasks.rb
# ===DESCRIPTION===================================================================================
#   QUERY_STRING= queue=b&numform=12
# ===LICENSE=======================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ==================================================================================================
require 'yaml'

PercentNumProcess=25
t = Time.now
CurrentYear=t.strftime("%Y")
fileConfig="/opt/grid-monitor/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)
PathMonitor="#{config["configuracion"]["pathDataFiles"]}/#{CurrentYear}/monitor"
PathImages=config["configuracion"]["pathImages"]
NameFileMonitorQueues=config["configuracion"]["nameFileMonitorQueues"]

def returnHTML(numProcQueued,imagenes)
if numProcQueued=="NONE" then
puts <<FIN_TXT
Content-type: text/html

#{imagenes}
FIN_TXT

 else

puts <<FIN_TXT
Content-type: text/html

<td class=hostTable>#{numProcQueued}&nbsp;</td>#{imagenes}
FIN_TXT
 end
end


if ENV['QUERY_STRING']==nil then
     returnHTML("ERROR","0","0")
else
     paramQueue,paramNumForm=ENV['QUERY_STRING'].split("&")
     field,inputQueue=paramQueue.split("=")
     field,inputNumForm=paramNumForm.split("=")
     ### Numero de procesos encolados en una cola determinada.
     fileDat=PathMonitor+"/"+NameFileMonitorQueues
     file = File.new(fileDat, "r")
     if File.zero?( fileDat ) then
        sleep 2 
     end
     numProcQueued=0
     statusQ="NONE"
     while (line = file.gets)
        line=line.chomp
        record=line.split("#")
        if record[0] == inputQueue then
            numProcQueued=record[2]
	    hostDataList=record[4].split("&")
	    hostDataList.each do | tokenHostData |
	        nameHost,dataHost=tokenHostData.split("=")
	        numRunTask,statusQueue=dataHost.split(",")
 	        if statusQueue=="RUN" then
	                statusQ=statusQueue
	        elsif statusQ!="RUN" then
	                statusQ=statusQueue
	        end
	    end
        end
     end
     file.close
     #percentQueuedTask= (numProcQueued.to_i * 100)  / PercentNumProcess
     #returnHTML(percentQueuedTask,inputNumForm,numProcQueued)
     imagenes=""
     if statusQ=="RUN" || statusQ=="SLEEP" then
	     if numProcQueued.to_i>0 then
	         for i in 0...numProcQueued.to_i
		         imagenes=imagenes+"<td class=hostTable><img src=\"#{PathImages}/red-dot2.png\" height=\"8\" width=\"4\"></td>"
		 end
	     else
	         numProcQueued=""
	     end
     else
             imagenes="<td class=hostTable width=\"100%\" align=CENTER style=\'color:white;background-color:red;table-layout:fixed;font-size:10px;font-weight:bold;text-align:center\'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CLOSED&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>"
             numProcQueued="NONE"
     end
     returnHTML(numProcQueued,imagenes)
end
