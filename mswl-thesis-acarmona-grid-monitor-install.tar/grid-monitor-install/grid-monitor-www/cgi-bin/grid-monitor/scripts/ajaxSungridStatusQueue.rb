#!/usr/bin/ruby
# ===NAME==========================================================================================
#    ajaxSungridStatusQueue.rb?QUEUE=uly-keep&NumForm=5&HOST=ALL
# ===DESCRIPTION===================================================================================
#    Devuelve el estado de una cola
# ===LICENSE=======================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ==================================================================================================
require 'yaml'

t = Time.now
CurrentYear=t.strftime("%Y")
fileConfig="/opt/grid-monitor/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)
PathMonitor="#{config["configuracion"]["pathDataFiles"]}/#{CurrentYear}/monitor"
NameFileMonitorQueues=config["configuracion"]["nameFileMonitorQueues"]
PathSunGridEngine=config["configuracion"]["pathGRID"]

def returnHTML(message)
puts <<FIN_TXT
Content-type: text/html

<html>
<head>
<title>SUNGRID ENGINE</title>
<META HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
#{message}
</body>
</html>
FIN_TXT
end

def getStatusQueue(inputQueue,inputHost)
  statusQ="NONE"
  statusQueue=`cat #{PathMonitor}/#{NameFileMonitorQueues} | grep \"#{inputQueue}\#"`.chomp
  f1,f2,f3,f4,f5=statusQueue.split("#")
  hostDataList=Array.new()
  if ! (f5.nil?) then
   hostDataList=f5.split("&")
   hostDataList.each do | tokenHostData |
        nameHost,dataHost=tokenHostData.split("=") 
        numRunTask,statusQueue=dataHost.split(",")
        if inputHost=="ALL" then
            if statusQueue=="RUN" then 
                statusQ=statusQueue 
            elsif statusQ!="RUN"
                statusQ=statusQueue
            end
        elsif nameHost==inputHost then
            statusQ=statusQueue
        end
    end
   end
   return statusQ
end


if ENV['QUERY_STRING']==nil then 
        returnHTML("ERROR")
else
     parmInputQueue,parmInputForm,parmInputHost=ENV['QUERY_STRING'].split("&")
     field,inputQueue=parmInputQueue.split("=")
     field,inputForm=parmInputForm.split("=")
     field,inputHost=parmInputHost.split("=")
     statusQUEUE=getStatusQueue(inputQueue,inputHost)
     labelQueue=inputQueue
     if inputHost!="ALL" then
          labelQueue="#{inputQueue}@#{inputHost}"
     end
 
     if statusQUEUE=="RUN" then
        htmlreturned="<a title=\"Disable Queue #{labelQueue}!\" href=\"javascript:disableQueue(\'#{inputQueue}\',\'#{inputHost}\')\">#{inputQueue}</a>"
     else
        htmlreturned="<a title=\"Enable Queue #{labelQueue}\" href=\"javascript:enableQueue(\'#{inputQueue}\',\'#{inputHost}\')\">#{inputQueue}</a>"
     end
     returnHTML(htmlreturned)
end
