#!/usr/bin/ruby
# ===NAME=================================================================================================
#    ajaxSungridShellList.rb?Project=CONTAVAL
# ===DESCRIPTION==========================================================================================
#    Este cgi devuelve una lista con las shells que son ejecutables de un proyecto.
# ===LICENSE==============================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ========================================================================================================
require 'yaml'

fileConfig="/opt/grid-monitor/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)

PathSunGridEngine=config["configuracion"]["pathGRID"]

def returnHTML(message)
puts <<FIN_TXT
Content-type: text/html

<html>
<head>
<title>SUNGRID ENGINE</title>
<META HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
Project: <SELECT NAME="Project" onclick="javascript:getShellList()">
#{message}
</SELECT>
</body>
</html>
FIN_TXT
end

htmlret=""
outPut=`ls /produccion`
outPut.each do | shellScript |
       shellScript=shellScript.chomp
       shellScriptFullPath="/produccion/#{shellScript}"
       if File.directory?(shellScriptFullPath) then
          htmlret=htmlret+"<OPTION VALUE=\"#{shellScript}\">#{shellScript}</OPTION>"
        end
end
returnHTML(htmlret)
