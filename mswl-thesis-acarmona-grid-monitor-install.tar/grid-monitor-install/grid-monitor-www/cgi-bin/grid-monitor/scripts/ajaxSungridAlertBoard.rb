#!/usr/bin/ruby
# ===NAME==========================================================================================
#    ajaxSungridAlertBoard.rb
# ===DESCRIPTION===================================================================================
#    Muestra alertas importantes en el cgi
# ===LICENSE=======================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ==================================================================================================
require 'yaml'

t = Time.now
CurrentYear=t.strftime("%Y")

fileConfig="/opt/grid-monitor/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)

PathSunGridEngine=config["configuracion"]["pathGRID"]

def returnHTML(message)
puts <<FIN_TXT
Content-type: text/html

<html>
<head>
<title>G R I D</title>
<META HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
#{message}
</body>
</html>
FIN_TXT
end

def isGridMonitorRunning()
   pidMonitor=`ps -ef | grep "grid-monitor" | grep -v grep | awk '{ print $2 }'` 
   return pidMonitor
end

if isGridMonitorRunning()!="" then
	alertMessage="<br>"
else
	alertMessage="<blink><img src=\"#{config["configuracion"]["pathImages"]}/notice-error.jpg\" width=\"15\" height=\"15\"><font face=\"Arial\" size=\"2\" color=\"red\">&nbsp;Monitor DOWN!</font></blink>"
end

returnHTML(alertMessage)
