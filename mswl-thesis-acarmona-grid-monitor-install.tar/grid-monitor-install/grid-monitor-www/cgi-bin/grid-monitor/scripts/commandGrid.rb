#!/usr/bin/ruby
# ===NAME======================================================================================
#    commandGrid.rb?CMD=CANCEL&SGEID=9264&DATE=201010&DATA=
# ===DESCRIPTION===============================================================================
#    Ejecuta comandos al grid
#    javascript:RelaunchProcess(i) hacer un qsub proceso, cola, parametros todo igual, buscar en fichero lista y hacer qaub
#    javascript:UnQueueProcess(i)  qdel <jobid>
#    javascript:killProcess(i)     qdel <jobid>
#    javascript:changeQueue(i)     qalter -q <cola> <jobid>
# ===LICENSE=======================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ==================================================================================================
require 'yaml'
fileConfig="/opt/grid-monitor/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)
t = Time.now
CurrentYear=t.strftime("%Y")
PathBase=config["configuracion"]["pathBase"]
PathSunGrid=config["configuracion"]["pathGRID"]
PathLog="#{config["configuracion"]["pathLog"]}/#{CurrentYear}/cgi"
PathDataFiles="#{config["configuracion"]["pathDataFiles"]}/#{CurrentYear}/tasks"
NameFileTaskList=config["configuracion"]["nameFileLista"]
NameFileStateList=config["configuracion"]["nameFileEstado"]
GridNameText=config["configuracion"]["gridNameText"]
ENV['SGE_ROOT']=config["configuracion"]["sgeRoot"]
ENV['SGE_CELL']=config["configuracion"]["sgeCell"]
ENV['SGE_CLUSTER_NAME']=config["configuracion"]["sgeClusterName"]
ENV['SGE_QMASTER_PORT']=config["configuracion"]["sgeQmasterPort"].to_s
ENV['SGE_EXECD_PORT']=config["configuracion"]["sgeExecdPort"].to_s
MailList=config["configuracion"]["mailList"]
ScriptSendMail=config["configuracion"]["scriptSendMail"]

def writeToLog(mensajeLog)
    t = Time.now
    fecha = t.strftime("%Y%m%d")
    fechaLog = t.strftime("%b %d %H:%M:%S")
    fileLog=PathLog+"/commandGrid"
    fileLog=fileLog+"-"+fecha+".log"
    logFile = File.new(fileLog, 'a+')
    logFile.puts fechaLog+" "+mensajeLog
    logFile.close
end

def sendReportMail(asuntoMail,bodyMail,mailbox)
   system "#{ScriptSendMail} \"#{mailbox}\" \"#{asuntoMail}\" \"#{bodyMail}\" \"#{asuntoMail}\""
end

def writeFileEstado(registro,inputDATE)
    if /^(\d\d\d\d)(\d\d)(\d\d)$/.match(inputDATE) then
        currentYear=$1
        fecha=inputDATE
    else
        writeToLog("ERROR: Error writeFileEstado EXPR-REG: #{inputDATE} NO paso expresion regular")
        exit 1
    end
    fileEstado=PathDataFiles+"/"+NameFileStateList+"."+fecha
    estadoFile = File.new(fileEstado, 'a+')
    File.chmod(0666,fileEstado)
    estadoFile.puts registro
    estadoFile.close
end

def getInfoTask(codesge,jobList,inputDATE)
    if /^(\d\d\d\d)(\d\d)(\d\d)$/.match(inputDATE) then
        currentYear=$1
    else
        writeToLog("ERROR: Error getInfoTask EXPR-REG: #{inputDATE} NO paso expresion regular")
        exit 1
    end
   fileLista=PathDataFiles+"/"+NameFileTaskList+"."+inputDATE
   targetPosition=0
   pos=1
   error=0
   begin
           file = File.new(fileLista, "r")
           while (line = file.gets)
             record=line.split("#")
             if record[0] == codesge then
               targetPosition=pos
              jobList['codesge']=record[0]
              jobList['typejob']=record[1]
              jobList['project']=record[2]
              jobList['nameId']=record[3]
              if record[1] == "SHELL" then
                 jobList['code']=record[4]
              else
                 jobList['code']=mesdia+"-"+record[4]
              end
              jobList['queuedDate']=record[5]
              jobList['user']=record[6]
              jobList['script']=record[7]
              jobList['arg']=record[8]
              jobList['pathlog']=record[9]
              jobList['queue']=record[10].chomp
             end
             pos=pos+1
           end
           file.close
   rescue
        writeToLog("ERROR: Error al intentar abrir #{fileLista}")
        error=1
   end
   return targetPosition,jobList,error
end


def returnHTML(message)
puts <<FIN_TXT
Content-type: text/html

<html>
<head>
<title>SUNGRID ENGINE</title>
<META HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
#{message}
</body>
</html>
FIN_TXT
end

jobList = {"codesge"=>[],"typejob"=>[],"code"=>[],"project"=>[],"nameId"=>[],"queuedDate"=>[],"user"=>[],"script"=>[],"arg"=>[],"pathlog"=>[],"queue"=>[]}

if ENV['QUERY_STRING']==nil then 
        returnHTML("ERROR")
else
     #writeToLog("INFO: Llamada a commandGrid.rb: QUERY_STRING: #{ENV['QUERY_STRING']} ")
     paramCMD,paramSGEID,paramDATE,paramDATA=ENV['QUERY_STRING'].split("&")
     aux,inputCMD=paramCMD.split("=")
     aux,inputSGEID=paramSGEID.split("=")
     aux,inputDATE=paramDATE.split("=")
     aux,inputDATA=paramDATA.split("=")

     inputSGEID=inputSGEID.gsub("%40","@")     
       
     t = Time.now 
     currentDate = t.strftime("%d%m%Y%H:%M:%S")
     if inputCMD == "CANCEL" then
        pos,jobList,error=getInfoTask(inputSGEID,jobList,inputDATE)
       	outPut=`#{PathSunGrid}/bin/lx24-amd64/qdel #{inputSGEID} 2>&1`
        writeToLog("EXE CANCEL User:#{ENV['REMOTE_USER']} qdel #{inputSGEID} Salida: #{outPut}")
        writeFileEstado("C#{pos}\##{inputSGEID}\##{jobList['typejob']}\##{jobList['project']}\##{jobList['nameId']}\#--#{currentDate}\##{jobList['queue']}\#CANCELLED\##{ENV['REMOTE_USER']}\#",inputDATE)     ### ESCRIBIR EN FICHERO ESTADO
        sendReportMail("Grid-#{GridNameText} monitor: CANCELLED: #{inputSGEID} #{jobList['nameId']}","El usuario #{ENV['REMOTE_USER']} ha cancelado el proceso: #{jobList['nameId']} Id:#{inputSGEID}",MailList)
      	system "logger -t \"Grid-#{GridNameText}\" \"CANCELLED: El usuario #{ENV['REMOTE_USER']} ha cancelado el proceso: #{jobList['nameId']} Id:#{inputSGEID}\""
     elsif inputCMD == "ABORT" then
        pos,jobList,error=getInfoTask(inputSGEID,jobList,inputDATE)
        outPut=`#{PathSunGrid}/bin/lx24-amd64/qdel #{inputSGEID} 2>&1`
        writeToLog("EXE ABORT User:#{ENV['REMOTE_USER']} qdel #{inputSGEID} Salida: #{outPut}")
        writeFileEstado("A#{pos}\##{inputSGEID}\##{jobList['typejob']}\##{jobList['project']}\##{jobList['nameId']}\#--#{currentDate}\##{jobList['queue']}\#ABORTED\##{ENV['REMOTE_USER']}\#",inputDATE)     ### ESCRIBIR EN FICHERO ESTADO
      	sendReportMail("Grid-#{GridNameText} monitor: ABORTED: #{inputSGEID} #{jobList['nameId']}","El usuario #{ENV['REMOTE_USER']} ha abortado el proceso: #{jobList['nameId']} Id:#{inputSGEID}",MailList)
      	system "logger -t \"Grid-#{GridNameText}\" \"ABORTED: El usuario #{ENV['REMOTE_USER']} ha abortado el proceso: #{jobList['nameId']} Id:#{inputSGEID}\""
     elsif inputCMD == "CHANGE"
        inputDATA=inputDATA.gsub("%40","@")
        pos,jobList,error=getInfoTask(inputSGEID,jobList,inputDATE)
      	outPut=`#{PathSunGrid}/bin/lx24-amd64/qalter -q #{inputDATA} #{inputSGEID} 2>&1`
        writeFileEstado("QA#{pos}\##{inputSGEID}\##{jobList['typejob']}\##{jobList['project']}\##{jobList['nameId']}\#--#{currentDate}\##{inputDATA}\#QUEUED\##{ENV['REMOTE_USER']}\#",inputDATE)
        writeToLog("EXE User:#{ENV['REMOTE_USER']} qalter -q #{inputDATA} #{inputSGEID} Salida: #{outPut}")
      	sendReportMail("Grid-#{GridNameText} monitor: CHANGE-QUEUE: #{inputSGEID} #{jobList['nameId']} cambiado a cola: #{inputDATA}","El usuario #{ENV['REMOTE_USER']} ha cambiado el proceso #{jobList['nameId']} a la cola: #{inputDATA}",MailList)
	      system "logger -t \"Grid-#{GridNameText}\" \"CHANGE-QUEUE: El usuario #{ENV['REMOTE_USER']} ha cambiado el proceso #{jobList['nameId']} a la cola: #{inputDATA}\""
     elsif inputCMD == "RESUBMIT"
        pos,jobList,error=getInfoTask(inputSGEID,jobList,inputDATE)
        commandQsub="#{PathBase}/bin/gqsub SHELL-#{inputSGEID} #{jobList['project']} #{jobList['nameId']} #{jobList['queue']} #{jobList['pathlog']} \"#{jobList['script']} #{jobList['arg']}\" 2>&1"
	      outPut=`#{commandQsub}`
        writeToLog("EXE User: #{ENV['REMOTE_USER']} Comando: #{commandQsub}")
        writeToLog("EXE User: #{ENV['REMOTE_USER']} Salida: #{outPut}")
        ##################################### Paso la tarea a estado RELAUNCHED ##########################################################
       	t = Time.now
	      currentTime = t.strftime("%d%m%Y%H:%M:%S")
      	dateField="--#{currentTime}"
      	registroState="RL#{pos}\##{inputSGEID}\#inputTypeTask\##{jobList['typejob']}\##{jobList['nameId']}\##{dateField}\##{jobList['queue']}\#Relaunched\##{jobList['user']}\#"
	      writeFileEstado(registroState,inputDATE)
      	##################################### Paso la tarea a estado RELAUNCHED ##########################################################
      	sendReportMail("Grid-#{GridNameText} monitor: #{inputSGEID} RESUBMIT de #{jobList['nameId']}","El usuario #{ENV['REMOTE_USER']} ha relanzado el proceso: #{jobList['nameId']} por la cola: #{jobList['queue']}. Output:#{outPut}",MailList)
      	system "logger -t \"Grid-#{GridNameText}\" \"RESUBMIT: El usuario #{ENV['REMOTE_USER']} ha relanzado el proceso: #{jobList['nameId']} por la cola: #{jobList['queue']}\""
     elsif inputCMD == "DISABLEQUEUE"
	      comando=""
       	if /^((\S+)-(x)|demons)@*\S*$/.match(inputSGEID) then
          		comando="qmod -d \"#{inputSGEID}\""
      	else
	          	comando="qconf -aattr queue load_thresholds \"rbc-STOP=0\" #{inputSGEID}"
      	end
        outPut=`#{PathSunGrid}/bin/lx24-amd64/#{comando} 2>&1`
        writeToLog("EXE User: #{ENV['REMOTE_USER']} #{comando} Salida: #{outPut}")
      	sendReportMail("Grid-#{GridNameText} monitor: DISABLE QUEUE: #{inputSGEID}","El usuario #{ENV['REMOTE_USER']} ha deshabilitado la cola: #{inputSGEID}",MailList)
      	system "logger -t \"Grid-#{GridNameText}\" \"DISABLE QUEUE: El usuario #{ENV['REMOTE_USER']} ha deshabilitado la cola: #{inputSGEID}\""
     elsif inputCMD == "ENABLEQUEUE"
        comando=""
        if /^((\S+)-(x)|demons)@*\S*$/.match(inputSGEID) then
                comando="qmod -e \"#{inputSGEID}\""
        else
                comando="qconf -dattr queue load_thresholds \"rbc-STOP=0\" #{inputSGEID}"
        end
        outPut=`#{PathSunGrid}/bin/lx24-amd64/#{comando} 2>&1`
        writeToLog("EXE User: #{ENV['REMOTE_USER']} #{comando} Salida: #{outPut}")
      	sendReportMail("Grid-#{GridNameText} monitor: ENABLE QUEUE: #{inputSGEID}","El usuario #{ENV['REMOTE_USER']} ha habilitado la cola: #{inputSGEID}",MailList)
	      system "logger -t \"Grid-#{GridNameText}\" \"ENABLE QUEUE: El usuario #{ENV['REMOTE_USER']} ha habilitado la cola: #{inputSGEID}\""
     elsif inputCMD == "ENABLEHOST"
        comando="qmod -e *@#{inputSGEID}" 
        outPut=`#{PathSunGrid}/bin/lx24-amd64/#{comando} 2>&1`
        writeToLog("EXE User: #{ENV['REMOTE_USER']} #{comando} Salida: #{outPut}")
      	sendReportMail("Grid-#{GridNameText} monitor: ENABLE HOST #{inputSGEID}","El usuario #{ENV['REMOTE_USER']} ha habilitado el host: #{inputSGEID}",MailList)
	      system "logger -t \"Grid-#{GridNameText}\" \"ENABLE HOST: El usuario #{ENV['REMOTE_USER']} ha habilitado el host: #{inputSGEID}\""
     elsif inputCMD == "DISABLEHOST"
        comando="qmod -d *@#{inputSGEID}"
        outPut=`#{PathSunGrid}/bin/lx24-amd64/#{comando} 2>&1`
        writeToLog("EXE User: #{ENV['REMOTE_USER']} #{comando} Salida: #{outPut}")
	      sendReportMail("Grid-#{GridNameText} monitor: DISABLE HOST #{inputSGEID}","El usuario #{ENV['REMOTE_USER']} ha deshabilitado el host: #{inputSGEID}",MailList)
	      system "logger -t \"Grid-#{GridNameText}\" \"DISABLE HOST: El usuario #{ENV['REMOTE_USER']} ha deshabilitado el host: #{inputSGEID}\""
     end
     returnHTML("")
end
