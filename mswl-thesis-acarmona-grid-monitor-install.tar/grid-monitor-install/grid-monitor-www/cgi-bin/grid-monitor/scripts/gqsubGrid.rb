#!/usr/bin/ruby
# ===NAME==========================================================================================
#    gqsubGrid.rb?CMD=GQSUB&TYPESHELL=SHELL&PROJECT=XXXX&NameJob=XXXX&QueueJob=XXXXX&PathLog=XXXXXX&CADENA=XXXXXX&ARGUMENTS=XXXXXXXX
# ===LICENSE=======================================================================================
#   Copyright (c) 2013 Antonio Carmona Alvarez (antcarbox@gmail.com) All rights reserved.
#
#   This file is part of grid-monitor
#
#   grid-monitor is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   grid-monitor is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with grid-monitor.  If not, see <http://www.gnu.org/licenses/>.
# ==================================================================================================
require 'yaml'
fileConfig="/opt/grid-monitor/etc/grid-configuration.yaml"
config = YAML.load_file(fileConfig)
t = Time.now
CurrentYear=t.strftime("%Y")
PathBase=config["configuracion"]["pathBase"]
PathSunGrid=config["configuracion"]["pathGRID"]
PathLog="#{config["configuracion"]["pathLog"]}/#{CurrentYear}/cgi"
PathDataFiles="#{config["configuracion"]["pathDataFiles"]}/#{CurrentYear}/tasks"
NameFileTaskList=config["configuracion"]["nameFileLista"]
NameFileStateList=config["configuracion"]["nameFileEstado"]
ENV['SGE_ROOT']=config["configuracion"]["sgeRoot"]
ENV['SGE_CELL']=config["configuracion"]["sgeCell"]
ENV['SGE_CLUSTER_NAME']=config["configuracion"]["sgeClusterName"]
ENV['SGE_QMASTER_PORT']=config["configuracion"]["sgeQmasterPort"].to_s
ENV['SGE_EXECD_PORT']=config["configuracion"]["sgeExecdPort"].to_s

def writeToLog(mensajeLog)
    t = Time.now
    fecha = t.strftime("%Y%m%d")
    fechaLog = t.strftime("%b %d %H:%M:%S")
    fileLog=PathLog+"/gqsubGrid"
    fileLog=fileLog+"-"+fecha+".log"
    logFile = File.new(fileLog, 'a+')
    logFile.puts fechaLog+" "+mensajeLog
    logFile.close
end

def returnHTML(message)
puts <<FIN_TXT
Content-type: text/html

<html>
<head>
<title>SUNGRID ENGINE</title>
<META HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
#{message}
</body>
</html>
FIN_TXT
end

writeToLog("INFO: #{ENV['QUERY_STRING']}")

if ENV['QUERY_STRING']==nil then 
        returnHTML("ERROR")
else
     # TYPESHELL=SHELL&PROJECT=XXXX&NameJob=XXXX&QueueJob=XXXXX&PathLog=XXXXXX&CADENA=XXXXXX&ARGUMENTS=XXXXXXXX
     paramTypeShell,paramProject,paramNameJob,paramQueueJob,paramPathLog,paramCadena,paramArguments=ENV['QUERY_STRING'].split("&")
     aux,inputTypeShell=paramTypeShell.split("=")
     aux,inputProject=paramProject.split("=")
     aux,inputNameJob=paramNameJob.split("=")
     aux,inputQueueJob=paramQueueJob.split("=")
     aux,inputPathLog=paramPathLog.split("=")
     aux,inputCadena=paramCadena.split("=")
     aux,inputArguments=paramArguments.split("=")

     inputCadena=inputCadena.gsub("%2F","/")
     inputArguments=inputArguments.gsub("%20"," ")
     inputArguments=inputArguments.gsub("%2F","/")
     inputPathLog=inputPathLog.gsub("%2F","/")

     t = Time.now 
     currentDate = t.strftime("%d%m%Y%H:%M:%S")

     if (inputArguments=="NONEPARAMS") then
	launchString=inputCadena
     else
	launchString="#{inputCadena} #{inputArguments}"
     end
     comando="#{PathBase}/bin/gqsub #{inputTypeShell} #{inputProject} #{inputNameJob} #{inputQueueJob} #{inputPathLog} \"#{launchString}\""
     writeToLog("INFO: LAUNCH: #{comando}")
     outPut=`#{comando} 2>&1`
     if ! outPut.index("ERROR").nil?
           outputHTML="<img src=\"#{config["configuracion"]["pathImages"]}/notice-error.jpg\" width=\"15\" height=\"15\"><font face=\"Arial\" size=\"2\" color=\"red\">&nbsp;#{outPut}</font>"
     else
           outputHTML="<img src=\"#{config["configuracion"]["pathImages"]}/notice-ok.gif\" width=\"15\" height=\"15\"><font face=\"Arial\" size=\"2\" color=\"green\">&nbsp;Lanzado #{launchString} Queue: #{inputQueueJob} ID-GRID: #{outPut} </font>"
     end
     returnHTML(outputHTML)
end
